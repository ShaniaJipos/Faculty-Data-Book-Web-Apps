<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Todo;

class TodoController extends Controller
{
    //
    public function home()
    {
        # code...
        $todos = Todo::all();

        return view('layouts.home', ['todos' => $todos]);
    }

    public function new(Request $request)
    {
        $newTodo = new Todo();
        $newTodo->task = $request->task;
        $newTodo->name = $request->name;
        $newTodo->email = $request->email;
        $newTodo->position = $request->position;
        $newTodo->degree = $request->degree;
        // $newTodo->major = $request->major;
        $newTodo->school = $request->school;
        $newTodo->year_started = $request->year_started;
        // $newTodo->year_end = $request->year_end;
        $newTodo->save();

        return redirect('/');
    }

    public function delete($id)
    {
        $todo = Todo::find($id);
        $todo->delete();

        return redirect('/');
    }


    public function update(Request $request)
    {
        $id = $request->id;
        $todo = $request->todo;

        $updateTodo = Todo::find($id);
        $updateTodo->todo = $todo;
        $updateTodo->save();

        return redirect('/');
    }

    public function complete($id)
    {
        $updateTodo = Todo::find($id);
        $updateTodo->is_complete = 1;
        $updateTodo->save();

        return redirect('/');
    }

    
    public function incomplete($id)
    {
        $updateTodo = Todo::find($id);
        $updateTodo->is_complete = 0;
        $updateTodo->save();

        return redirect('/');
    }

    public function createtodo(Request $request)
    {
        return view("layouts.newtodo");
    }
}
