function confirmation(id) {
    if (confirm('Do you want to proceed?')) {
        document.getElementById(id).submit();
    } else {
        return false;
    }
}

$("#new-todo").on("click", function() {
    var todo = prompt("Todo: ");

    if (todo) {
        $("#new-todo-input").val(todo);
        confirmation("new-todo-form");
    }
});

$(".update-todo").on("click", function() {
    var id = $(this).attr("data-id");
    var todo_ = $(this).attr("data-todo");
    var todo = prompt("Update Todo: ", todo_);

    if (todo) {
        $("#update-id-input").val(id);
        $("#update-todo-input").val(todo);
        confirmation("update-todo-form");
    }
});