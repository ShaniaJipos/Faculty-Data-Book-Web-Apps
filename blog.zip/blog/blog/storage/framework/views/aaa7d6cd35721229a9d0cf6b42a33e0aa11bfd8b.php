<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-md-3 card p-3 mt-5">
                <h3>New todo</h3>
                <form action="new" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="text" name="todo" class="form-control mt-2" id="" required placeholder="Todo">
                    <input type="text" name="name" class="form-control mt-2" id="" required placeholder="Name">
                    <input type="email" name="email" class="form-control mt-2" id="" required placeholder="Email">
                    <input type="text" name="position" class="form-control mt-2" id="" required placeholder="Position">
                    <input type="text" name="degree" class="form-control mt-2" id="" required placeholder="Degree">
                    
                    <input type="text" name="school" class="form-control mt-2" id="" required placeholder="School Graduated">
                    <input type="text" name="year_started" class="form-control mt-2" id="" required placeholder="Year Started">
                    
                    <a href="/"><button type="button" class="btn btn-warning mt-3">Back</button></a>
                    <button class="btn btn-success mt-3">Create</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\blog\blog\resources\views/layouts/newtodo.blade.php ENDPATH**/ ?>