<?php $__env->startSection('content'); ?>
    <div class="container pt-5">

        
        <a href="createtodo">
            <button class="btn btn-success float-right">New todo</button></a>
        
        

        <h1>Faculty Data Book Web App</h1>
        <div class="row">
            <div class="col-md">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <th>ID NO.</th>
                            <th class="todo">Task</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Position</th>
                            
                            <th>Degree</th>
                            
                            <th>School 
                                Graduated</th>
                            <th>Year Started</th>
                            
                            <th>Status</th>
                            
                            <th>Action</th>
                        </thead>
                        <tbody>
                            <?php $count = 1; ?>
                            <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($count++); ?>.</td>
                                    <td><?php echo e($todo->task); ?></td>
                                    
                                    <td><?php echo e($todo->name); ?></td>
                                    <td><?php echo e($todo->email); ?></td>
                                    <td><?php echo e($todo->position); ?></td>
                                    <td><?php echo e($todo->degree); ?></td>
                                    
                                    <td><?php echo e($todo->school); ?></td>
                                    <td><?php echo e($todo->year_started); ?></td>
                                    
                                    <td><?php echo e($todo->is_complete == 0 ? 'Not complete' : 'Completed'); ?></td>
                                    
                                    <td>
                                        <?php if($todo->is_complete == 0): ?>
                                            <a href="complete/<?php echo e($todo->id); ?>"><button
                                                    class="btn btn-block btn-primary">Complete</button></a>
                                        <?php else: ?>
                                            <a href="incomplete/<?php echo e($todo->id); ?>"><button
                                                    class="btn btn-block btn-warning">Incomplete</button></a>
                                        <?php endif; ?>
                                        <button class="btn btn-block mt-2 btn-info update-todo" data-id="<?php echo e($todo->id); ?>"
                                            data-todo="<?php echo e($todo->todo); ?>">Update</button>
                                        <a href="delete/<?php echo e($todo->id); ?>"><button type="button"
                                                class="btn btn-block mt-2 btn-danger">Delete</button></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <form action="update" method="post" id="update-todo-form">
                                <?php echo csrf_field(); ?>
                                <input type="text" id="update-id-input" name="id" hidden>
                                <input type="text" id="update-todo-input" name="todo" hidden>
                            </form>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\blog\blog\resources\views/layouts/home.blade.php ENDPATH**/ ?>