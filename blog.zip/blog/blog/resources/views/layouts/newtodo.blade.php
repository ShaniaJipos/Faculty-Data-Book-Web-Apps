@extends('templates.main')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-md-3 card p-3 mt-5">
                <h3>New todo</h3>
                <form action="new" method="post">
                    @csrf
                    <input type="text" name="task" class="form-control mt-2" id="" required placeholder="TASK">
                    <input type="text" name="name" class="form-control mt-2" id="" required placeholder="Name">
                    <input type="email" name="email" class="form-control mt-2" id="" required placeholder="Email">
                    <input type="text" name="position" class="form-control mt-2" id="" required placeholder="Position">
                    <input type="text" name="degree" class="form-control mt-2" id="" required placeholder="Degree">
                    {{-- <input type="text" name="major" class="form-control mt-2" id="" required placeholder="Major"> --}}
                    <input type="text" name="school" class="form-control mt-2" id="" required placeholder="School Graduated">
                    <input type="text" name="year_started" class="form-control mt-2" id="" required placeholder="Year Started">
                    {{-- <input type="text" name="year_end" class="form-control mt-2" id="" required placeholder="Year Graduated"> --}}
                    <a href="/"><button type="button" class="btn btn-warning mt-3">Back</button></a>
                    <button class="btn btn-success mt-3">Create</button>
                </form>
            </div>
        </div>
    </div>
@endsection