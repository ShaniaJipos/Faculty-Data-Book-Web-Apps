@extends('templates.main')

@section('content')
    <div class="container pt-5">

        {{-- New todo --}}
        <a href="createtodo">
            <button class="btn btn-success float-right">New todo</button></a>
        {{-- <button class="btn btn-success float-right" id="new-todo">New todo</button> --}}
        {{-- <form action="new" method="post" id="new-todo-form">
            @csrf
            <input type="text" id="new-todo-input" name="todo" hidden>
        </form> --}}

        <h1>Faculty Data Book Web App</h1>
        <div class="row">
            <div class="col-md">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <th>ID NO.</th>
                            <th class="todo">Task</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Position</th>
                            {{-- <th>Birthdate</th> --}}
                            <th>Degree</th>
                            {{-- <th>Major</th> --}}
                            <th>School 
                                Graduated</th>
                            <th>Year Started</th>
                            {{-- <th>Year Graduated</th> --}}
                            <th>Status</th>
                            {{-- <th>Created at</th>
                            <th>Updated at</th> --}}
                            <th>Action</th>
                        </thead>
                        <tbody>
                            <?php $count = 1; ?>
                            @foreach ($todos as $todo)
                                <tr>
                                    <td>{{ $count++ }}.</td>
                                    <td>{{ $todo->task }}</td>
                                    {{-- <td>{{ $todo->birthdate }}</td> --}}
                                    <td>{{ $todo->name }}</td>
                                    <td>{{ $todo->email }}</td>
                                    <td>{{ $todo->position }}</td>
                                    <td>{{ $todo->degree }}</td>
                                    {{-- <td>{{ $todo->major }}</td> --}}
                                    <td>{{ $todo->school }}</td>
                                    <td>{{ $todo->year_started }}</td>
                                    {{-- <td>{{ $todo->year_end }}</td> --}}
                                    <td>{{ $todo->is_complete == 0 ? 'Not complete' : 'Completed' }}</td>
                                    {{-- <td>{{ $todo->created_at }}</td>
                                    <td>{{ $todo->updated_at }}</td> --}}
                                    <td>
                                        @if ($todo->is_complete == 0)
                                            <a href="complete/{{ $todo->id }}"><button
                                                    class="btn btn-block btn-primary">Complete</button></a>
                                        @else
                                            <a href="incomplete/{{ $todo->id }}"><button
                                                    class="btn btn-block btn-warning">Incomplete</button></a>
                                        @endif
                                        <button class="btn btn-block mt-2 btn-info update-todo" data-id="{{ $todo->id }}"
                                            data-todo="{{ $todo->todo }}">Update</button>
                                        <a href="delete/{{ $todo->id }}"><button type="button"
                                                class="btn btn-block mt-2 btn-danger">Delete</button></a>
                                    </td>
                                </tr>
                            @endforeach

                            <form action="update" method="post" id="update-todo-form">
                                @csrf
                                <input type="text" id="update-id-input" name="id" hidden>
                                <input type="text" id="update-todo-input" name="todo" hidden>
                            </form>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
